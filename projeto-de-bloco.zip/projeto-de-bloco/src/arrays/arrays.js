export const VAGAS = [
  {
    id: '1',
    title: 'Senior Full-stack Developer',
    company: 'Lemon.io',
    location: 'Americas, Europe, Asia',
  },
  {
    id: '2',
    title: 'Software Engineer (Global)',
    company: 'Jump',
    location: 'Worldwide',
  },
  {
    id: '3',
    title: 'Frontend Developer (React)',
    company: 'Tech Solutions',
    location: 'Remoto',
  },
  {
    id: '4',
    title: 'UI/UX Designer',
    company: 'Creative Minds',
    location: 'São Paulo, Brasil',
  },
];

